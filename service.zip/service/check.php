<?php
$homepage = file_get_contents('http://black-hg.org/cc/');
if($homepage){
echo $homepage
}
?>